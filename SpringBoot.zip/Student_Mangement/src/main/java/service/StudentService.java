package service;

public interface StudentService {

}
