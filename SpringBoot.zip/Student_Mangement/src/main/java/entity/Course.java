package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name="course")
@Entity
public class Course {
	
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name="course_id")
	 private Integer courseID;
	
	 @Column(name="course_name")
	 private String courseName;

	
	 @Column(name="duration")
	 private int duration;

	

	public Course() {
		super();
	}


	public Course(Integer courseID, String courseName, int duration) {
		super();
		this.courseID = courseID;
		this.courseName = courseName;
		this.duration = duration;
	}


	public Course(String courseName, int duration) {
		super();
		this.courseName = courseName;
		this.duration = duration;
	}


	public Integer getCourseID() {
		return courseID;
	}


	public void setCourseID(Integer courseID) {
		this.courseID = courseID;
	}


	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	@Override
	public String toString() {
		return "Course [courseID=" + courseID + ", courseName=" + courseName + ", duration=" + duration + "]";
	}
	
	
	


	
	
}
	
	
	
	