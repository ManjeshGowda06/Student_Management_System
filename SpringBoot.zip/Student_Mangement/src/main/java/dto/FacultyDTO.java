package dto;

import entity.Department;

public class FacultyDTO {
	
	
	private int facultyId;

	private String facultyName;

	private String courseHandeld;

	private String phoneNo;

	private String emailId;

	private String designation;

	private int noOfYearExperience;

	private Department department;

	
	
	
	public FacultyDTO(int facultyId, String facultyName, String courseHandeld, String phoneNo, String emailId,
			String designation, int noOfYearExperience, Department department) {
		super();
		this.facultyId = facultyId;
		this.facultyName = facultyName;
		this.courseHandeld = courseHandeld;
		this.phoneNo = phoneNo;
		this.emailId = emailId;
		this.designation = designation;
		this.noOfYearExperience = noOfYearExperience;
		this.department = department;
	}

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultyName() {
		return facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}

	public String getCourseHandeld() {
		return courseHandeld;
	}

	public void setCourseHandeld(String courseHandeld) {
		this.courseHandeld = courseHandeld;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getNoOfYearExperience() {
		return noOfYearExperience;
	}

	public void setNoOfYearExperience(int noOfYearExperience) {
		this.noOfYearExperience = noOfYearExperience;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	
	
	
	
	
	
	
	
}
