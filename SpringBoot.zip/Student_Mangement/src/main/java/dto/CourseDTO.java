package dto;
//import lombok.AllArgsConstructor;
//import lombok.NoArgsConstructor;
//import lombok.Data;
//
//
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data

public class CourseDTO {


	 private Integer courseID;
	
	 private String courseName;

	
	 private int duration;


	public CourseDTO(Integer courseID, String courseName, int duration) {
		super();
		this.courseID = courseID;
		this.courseName = courseName;
		this.duration = duration;
	}


	public Integer getCourseID() {
		return courseID;
	}


	public void setCourseID(Integer courseID) {
		this.courseID = courseID;
	}


	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}
	 
	 
}
