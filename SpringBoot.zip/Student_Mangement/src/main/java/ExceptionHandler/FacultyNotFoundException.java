package ExceptionHandler;

public class FacultyNotFoundException extends RuntimeException{

	public FacultyNotFoundException(String message) {
		super(message);

	}
}
